import unittest
from app import generate_metrics
from config import NUM_APPS

class TestMetricsGeneration(unittest.TestCase):
    def test_number_of_apps(self):
        metrics = generate_metrics()
        self.assertEqual(len(metrics), NUM_APPS)

    def test_metric_values(self):
        metrics = generate_metrics()
        for value in metrics.values():
            self.assertGreaterEqual(value, 1)
            self.assertLessEqual(value, 12000)

if __name__ == "__main__":
    unittest.main()