import unittest
from unittest.mock import patch
from app import app, generate_metrics, periodic_metrics_generation, display_top_apps
from metrics_manager import MetricsManager
from config import THRESHOLD, TOP_X_APPS

class TestApp(unittest.TestCase):
    def setUp(self):
        # Create a test client for the Flask app
        self.client = app.test_client()
        app.config['TESTING'] = True

        # Create a new MetricsManager instance for the test
        self.metrics_manager = MetricsManager()

        # Debug log to check if MetricsManager is re-initialized
        print(f"MetricsManager instance: {id(self.metrics_manager)}")
        print(f"exceedance_count type: {type(self.metrics_manager.exceedance_count)}")

    def tearDown(self):
        """Reset the metrics_manager state after each test."""
        self.metrics_manager.metrics_history.clear()
        self.metrics_manager.exceedance_count.clear()

    def test_metrics_endpoint(self):
        """Test the /metrics endpoint."""
        response = self.client.get('/metrics')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'bigquery_written_bytes', response.data)

    def test_generate_metrics(self):
        """Test the generate_metrics function."""
        metrics = generate_metrics()
        self.assertIsInstance(metrics, dict)
        self.assertEqual(len(metrics), 6)  # Assuming NUM_APPS is 6
        for key, value in metrics.items():
            self.assertTrue(key.startswith('app'))
            self.assertGreaterEqual(value, 1)
            self.assertLessEqual(value, 12000)

    @patch('app.time.sleep')  # Mock time.sleep to avoid waiting
    @patch('app.generate_metrics')  # Mock generate_metrics to control output
    def test_periodic_metrics_generation(self, mock_generate_metrics, mock_sleep):
        """Test the periodic_metrics_generation function."""
        # Mock generate_metrics to return a fixed set of metrics
        mock_generate_metrics.return_value = {"app1": THRESHOLD + 1, "app2": THRESHOLD - 1}

        # Reset the exceedance_count dictionary
        self.metrics_manager.exceedance_count.clear()

        # Call the function with a limited number of iterations
        periodic_metrics_generation(max_iterations=1)

        # Ensure time.sleep was called
        mock_sleep.assert_called()

        # Ensure generate_metrics was called
        mock_generate_metrics.assert_called()

        # Verify the exceedance_count is updated
        self.assertEqual(self.metrics_manager.exceedance_count["app1"], 1)
        self.assertEqual(self.metrics_manager.exceedance_count["app2"], 0)

    def test_exceeding_endpoint(self):
        """Test the /exceeding endpoint."""
        # Simulate exceedance counts
        self.metrics_manager.exceedance_count = {"app1": 5, "app2": 3}

        # Access the /exceeding endpoint
        response = self.client.get('/exceeding')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Top 2 Apps Exceeding Threshold', response.data)  # Updated to match actual title
        self.assertIn(b'app1', response.data)
        self.assertIn(b'app2', response.data)

    @patch('builtins.print')  # Mock print to test console output
    def test_display_top_apps_console(self, mock_print):
        """Test the display_top_apps function in console mode."""
        top_apps = [("app1", 5), ("app2", 3)]
        display_top_apps(top_apps)
        mock_print.assert_called_with(f"Top {TOP_X_APPS} apps exceeding threshold: {top_apps}")

if __name__ == "__main__":
    unittest.main()